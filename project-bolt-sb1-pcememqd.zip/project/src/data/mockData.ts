export type Position = 'GK' | 'DEF' | 'MID' | 'FWD';

export interface Player {
  id: number;
  nickname: string;
  club: string;
  position: Position;
  rating: number;
  goals: number;
  assists: number;
  matches: number;
  country: string;
}

export interface ClubAchievement {
  title: string;
  season: string;
  icon?: string;
}

export interface ClubKeyPerson {
  name: string;
  role: string;
  avatar?: string;
}

export interface Club {
  id: string;
  name: string;
  tag: string;
  country: string;
  logo: string;
  status: 'active' | 'inactive';
  founded: string;
  history: string;
  achievements: ClubAchievement[];
  keyPersons: ClubKeyPerson[];
  trophies: number;
  roster: string[];
  achievement: string;
  accent: string;
  note?: string;
}

export interface SeasonChampion {
  id: number;
  season: string;
  champion: string;
  runnerUp: string;
  mvp: string;
  date: string;
}

export interface Award {
  id: number;
  title: string;
  winner: string;
  description: string;
  icon?: 'ballondor' | 'boot' | 'playmaker' | 'defender' | 'glove' | 'boy' | 'manager';
  season?: string;
  alias?: string;
}

export interface BallonDorEntry {
  rank: number;
  nickname: string;
  alias: string;
  position: string;
  potms: number;
  goals: number;
  assists: number;
  note: string;
  medal: 'gold' | 'silver' | 'bronze';
}

export interface TopScorer {
  rank: number;
  nickname: string;
  goals: number;
}

export const positionLabels: Record<Position, string> = {
  GK: 'Вратарь',
  DEF: 'Защитник',
  MID: 'Полузащитник',
  FWD: 'Нападающий',
};

export const stats = {
  totalPlayers: 180,
  activeClubs: 6,
  seasonsPlayed: 3,
  prizePool: '3 Пачки кириешек и почет от Рино',
};


export const currentSeason = {
  number: 3,
  name: 'CIS League Season 3 (CIS Cup)',
  status: 'Идёт 3-й сезон',
  startDate: '2026',
  endDate: '2026',
  prizePool: '3 Пачки кириешек и почет от Рино',
  teams: 6,
  description:
    'Третий сезон главной VRFS-лиги СНГ. 6 элитных клубов соревнуются за звание чемпионов региона.',
};

export const hallOfFame: SeasonChampion[] = [
  { id: 1, season: 'Season 1', champion: 'Шахтар Донецк', runnerUp: 'Академия', mvp: 'florixxx', date: '2025' },
  { id: 2, season: 'Season 2', champion: 'Performance FC', runnerUp: '—', mvp: 'RiNO', date: '2025' },
  { id: 3, season: 'Season 3 (CIS Cup)', champion: 'Performance FC', runnerUp: '—', mvp: '—', date: '2026' },
];

export const topScorersS1: TopScorer[] = [
  { rank: 1, nickname: 'florixxx', goals: 19 },
  { rank: 2, nickname: 'RiNO', goals: 9 },
  { rank: 3, nickname: 'TʜᴇDᴏk', goals: 8 },
  { rank: 4, nickname: 'savaldinho', goals: 5 },
  { rank: 5, nickname: 'maximtelli', goals: 4 },
  { rank: 6, nickname: 'ronpuzis', goals: 4 },
  { rank: 7, nickname: 'DemIK$', goals: 3 },
  { rank: 8, nickname: 'Mythic', goals: 3 },
  { rank: 9, nickname: 'GRISHALIK', goals: 3 },
  { rank: 10, nickname: 'krupiv23', goals: 3 },
];

export const topScorersS2: TopScorer[] = [
  { rank: 1, nickname: 'RiNO', goals: 9 },
  { rank: 2, nickname: 'Lioris', goals: 5 },
  { rank: 3, nickname: 'TʜᴇDᴏk', goals: 4 },
  { rank: 4, nickname: 'FLIзи', goals: 3 },
  { rank: 5, nickname: 'TORTIK', goals: 1 },
  { rank: 6, nickname: 'Yuto Kochegarov', goals: 1 },
  { rank: 7, nickname: 'Suslik', goals: 1 },
];

export const ballonDorS1: BallonDorEntry[] = [
  { rank: 1, nickname: 'florixx', alias: 'Пупок', position: 'Striker', potms: 4, goals: 19, assists: 4, note: 'Победитель S1', medal: 'gold' },
  { rank: 2, nickname: 'Dok', alias: 'Док', position: 'Winger', potms: 2, goals: 8, assists: 5, note: '2-е место', medal: 'silver' },
  { rank: 3, nickname: 'RINO PAPA', alias: 'Рино Папа', position: 'Striker', potms: 3, goals: 9, assists: 4, note: '3-е место', medal: 'bronze' },
];

export const seasonAwards: { season: string; year: string; awards: Award[] }[] = [
  {
    season: 'CIS League S1',
    year: '2025',
    awards: [
      { id: 101, title: 'Ballon d\'Or winner', winner: 'florixxx', alias: 'Пупок', description: 'Лучший игрок сезона по версии Ballon d\'Or', icon: 'ballondor', season: 'S1' },
      { id: 102, title: 'Golden Boot winner', winner: 'florixxx', alias: 'Пупок', description: 'Лучший бомбардир сезона', icon: 'boot', season: 'S1' },
      { id: 103, title: 'Best Playmaker winner', winner: 'Ƭʜᴇ𝕯𝖔k🔝', alias: 'Док', description: 'Лучший плеймейкер сезона', icon: 'playmaker', season: 'S1' },
      { id: 104, title: 'Best Defender winner', winner: 'Rosha', alias: 'Роша', description: 'Лучший защитник сезона', icon: 'defender', season: 'S1' },
      { id: 105, title: 'Golden Glove winner', winner: 'Avariyan', alias: 'Аир', description: 'Лучший вратарь сезона', icon: 'glove', season: 'S1' },
    ],
  },
  {
    season: 'CIS League S2',
    year: '2025',
    awards: [
      { id: 201, title: 'Ballon d\'Or winner', winner: 'RiNO', alias: 'Рино', description: 'Лучший игрок сезона по версии Ballon d\'Or', icon: 'ballondor', season: 'S2' },
      { id: 202, title: 'Golden Boot winner', winner: 'RiNO', alias: 'Рино', description: 'Лучший бомбардир сезона', icon: 'boot', season: 'S2' },
      { id: 203, title: 'Golden Boy winner', winner: 'Space7₊⋆⁺₊❅。', alias: 'Спейс', description: 'Открытие сезона — лучший молодой игрок', icon: 'boy', season: 'S2' },
      { id: 204, title: 'Best Playmaker winner', winner: 'Space7₊⋆⁺₊❅。', alias: 'Спейс', description: 'Лучший плеймейкер сезона', icon: 'playmaker', season: 'S2' },
      { id: 205, title: 'Best Defender winner', winner: 'kakaska', alias: 'Какашка', description: 'Лучший защитник сезона', icon: 'defender', season: 'S2' },
      { id: 206, title: 'Golden Glove winner', winner: 'Deleted User', alias: 'Йен', description: 'Лучший вратарь сезона', icon: 'glove', season: 'S2' },
      { id: 207, title: 'Best Manager winner', winner: 'Trustme', alias: 'Секрет', description: 'Лучший менеджер/тренер сезона', icon: 'manager', season: 'S2' },
    ],
  },
];

export const players: Player[] = [
  { id: 1, nickname: 'KraZer', club: 'Red Wolves', position: 'FWD', rating: 94, goals: 38, assists: 12, matches: 24, country: 'RU' },
  { id: 2, nickname: 'Vortex', club: 'Crimson Guard', position: 'MID', rating: 93, goals: 14, assists: 28, matches: 26, country: 'UA' },
  { id: 3, nickname: 'Nordlys', club: 'Northern Eagles', position: 'FWD', rating: 92, goals: 34, assists: 9, matches: 25, country: 'BY' },
  { id: 4, nickname: 'Falcon', club: 'Red Wolves', position: 'FWD', rating: 91, goals: 42, assists: 6, matches: 24, country: 'KZ' },
  { id: 5, nickname: 'Dmitriy_S', club: 'Crimson Guard', position: 'MID', rating: 90, goals: 18, assists: 22, matches: 26, country: 'RU' },
  { id: 6, nickname: 'SteppeEagle', club: 'Steppes United', position: 'FWD', rating: 90, goals: 31, assists: 11, matches: 23, country: 'KZ' },
  { id: 7, nickname: 'IronHand', club: 'Volga FC', position: 'GK', rating: 89, goals: 0, assists: 2, matches: 27, country: 'RU' },
  { id: 8, nickname: 'Morozov', club: 'Northern Eagles', position: 'DEF', rating: 88, goals: 3, assists: 8, matches: 25, country: 'RU' },
  { id: 9, nickname: 'Bekzat', club: 'Steppes United', position: 'MID', rating: 88, goals: 12, assists: 19, matches: 23, country: 'KZ' },
  { id: 10, nickname: 'Lavr', club: 'Red Wolves', position: 'DEF', rating: 87, goals: 4, assists: 6, matches: 24, country: 'UA' },
  { id: 11, nickname: 'SanyaPro', club: 'Crimson Guard', position: 'FWD', rating: 87, goals: 26, assists: 10, matches: 26, country: 'RU' },
  { id: 12, nickname: 'Gunner77', club: 'Volga FC', position: 'FWD', rating: 86, goals: 29, assists: 7, matches: 27, country: 'RU' },
  { id: 13, nickname: 'VladKO', club: 'Northern Eagles', position: 'MID', rating: 86, goals: 9, assists: 16, matches: 25, country: 'BY' },
  { id: 14, nickname: 'MaxSteel', club: 'Crimson Guard', position: 'DEF', rating: 85, goals: 2, assists: 5, matches: 26, country: 'RU' },
  { id: 15, nickname: 'Aibek', club: 'Steppes United', position: 'GK', rating: 85, goals: 0, assists: 1, matches: 23, country: 'KZ' },
  { id: 16, nickname: 'Drozd', club: 'Red Wolves', position: 'MID', rating: 84, goals: 11, assists: 14, matches: 24, country: 'RU' },
  { id: 17, nickname: 'Petrovich', club: 'Volga FC', position: 'DEF', rating: 84, goals: 5, assists: 4, matches: 27, country: 'RU' },
  { id: 18, nickname: 'Olegator', club: 'Caucasus FC', position: 'FWD', rating: 83, goals: 24, assists: 8, matches: 22, country: 'RU' },
  { id: 19, nickname: 'Nurzhan', club: 'Steppes United', position: 'DEF', rating: 83, goals: 3, assists: 7, matches: 23, country: 'KZ' },
  { id: 20, nickname: 'Sokol', club: 'Northern Eagles', position: 'FWD', rating: 82, goals: 21, assists: 12, matches: 25, country: 'UA' },
  { id: 21, nickname: 'Vityaz', club: 'Red Wolves', position: 'GK', rating: 82, goals: 0, assists: 0, matches: 24, country: 'RU' },
  { id: 22, nickname: 'MishaX', club: 'Crimson Guard', position: 'FWD', rating: 81, goals: 19, assists: 13, matches: 26, country: 'RU' },
  { id: 23, nickname: 'Andriy', club: 'Dnipro Squad', position: 'MID', rating: 81, goals: 13, assists: 15, matches: 21, country: 'UA' },
  { id: 24, nickname: 'Kostya', club: 'Volga FC', position: 'MID', rating: 80, goals: 8, assists: 18, matches: 27, country: 'RU' },
  { id: 25, nickname: 'Romanov', club: 'Northern Eagles', position: 'GK', rating: 80, goals: 0, assists: 1, matches: 25, country: 'BY' },
  { id: 26, nickname: 'Dauren', club: 'Caucasus FC', position: 'MID', rating: 79, goals: 10, assists: 12, matches: 22, country: 'KZ' },
  { id: 27, nickname: 'IgorPL', club: 'Dnipro Squad', position: 'DEF', rating: 79, goals: 4, assists: 6, matches: 21, country: 'UA' },
  { id: 28, nickname: 'SergeyK', club: 'Volga FC', position: 'FWD', rating: 78, goals: 17, assists: 9, matches: 27, country: 'RU' },
  { id: 29, nickname: 'Temir', club: 'Steppes United', position: 'FWD', rating: 78, goals: 15, assists: 11, matches: 23, country: 'KZ' },
  { id: 30, nickname: 'Yarik', club: 'Crimson Guard', position: 'DEF', rating: 77, goals: 2, assists: 8, matches: 26, country: 'RU' },
  { id: 31, nickname: 'Bogdan', club: 'Dnipro Squad', position: 'FWD', rating: 77, goals: 22, assists: 5, matches: 21, country: 'UA' },
  { id: 32, nickname: 'Anton99', club: 'Caucasus FC', position: 'GK', rating: 76, goals: 0, assists: 0, matches: 22, country: 'RU' },
  { id: 33, nickname: 'VovaT', club: 'Red Wolves', position: 'MID', rating: 76, goals: 7, assists: 10, matches: 24, country: 'RU' },
  { id: 34, nickname: 'PavelM', club: 'Northern Eagles', position: 'DEF', rating: 75, goals: 1, assists: 4, matches: 25, country: 'RU' },
  { id: 35, nickname: 'Ruslan', club: 'Caucasus FC', position: 'FWD', rating: 75, goals: 14, assists: 7, matches: 22, country: 'KZ' },
  { id: 36, nickname: 'Kolyan', club: 'Volga FC', position: 'DEF', rating: 74, goals: 3, assists: 3, matches: 27, country: 'RU' },
  { id: 37, nickname: 'GenaX', club: 'Dnipro Squad', position: 'MID', rating: 74, goals: 6, assists: 9, matches: 21, country: 'UA' },
  { id: 38, nickname: 'Stasik', club: 'Steppes United', position: 'MID', rating: 73, goals: 5, assists: 8, matches: 23, country: 'RU' },
  { id: 39, nickname: 'DenV', club: 'Crimson Guard', position: 'GK', rating: 73, goals: 0, assists: 0, matches: 26, country: 'RU' },
  { id: 40, nickname: 'TimurK', club: 'Caucasus FC', position: 'DEF', rating: 72, goals: 1, assists: 2, matches: 22, country: 'KZ' },
];

export const clubs: Club[] = [
  {
    id: 'shakhtar',
    name: 'Шахтар Донецк',
    tag: 'ШХТ',
    country: 'Украина',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/a/a1/FC_Shakhtar_Donetsk.svg',
    status: 'active',
    founded: 'Season 1',
    history: 'Один из клубов-основателей CIS League, регулярно сражающийся за высшие места в турнирной таблице. Шахтар задал высокий стандарт организации и стал первым чемпионом лиги.',
    achievements: [
      { title: 'Чемпион CIS League', season: 'Season 1', icon: 'trophy' },
      { title: 'Обладатель CIS Cup', season: 'Season 1', icon: 'cup' },
      { title: 'Топ-1 клуб СНГ', season: 'Season 1', icon: 'medal' },
    ],
    keyPersons: [
      { name: 'florixxx', role: 'Капитан и лучший бомбардир', avatar: 'florixxx' },
      { name: 'Kairo', role: 'Ключевой игрок атаки', avatar: 'Kairo' },
      { name: 'Emik', role: 'Легендарный вратарь', avatar: 'Emik' },
    ],
    trophies: 2,
    roster: ['florixxx', 'Kairo', 'krupiv23', 'nkay_', 'Emik', 'Lioris'],
    achievement: 'Чемпион 1-го сезона Лиги и Кубка. Топ-1 клуб СНГ.',
    accent: 'from-rose-600 to-rose-900',
    note: 'Топ-1 клуб СНГ',
  },
  {
    id: 'latvia',
    name: 'Latvia FC',
    tag: 'LFC',
    country: 'Латвия',
    logo: '/image copy 2.png',
    status: 'active',
    founded: 'Season 1',
    history: 'Команда с отличной командной дисциплиной, представляющая игроков из Латвии и СНГ. Latvia FC уверенно прошла первые сезоны и закрепилась среди сильнейших клубов региона.',
    achievements: [
      { title: 'Участник плей-офф', season: 'Season 2', icon: 'medal' },
      { title: 'Финалист сезона', season: 'Season 3', icon: 'final' },
    ],
    keyPersons: [
      { name: 'Latvia Captain', role: 'Основатель и капитан', avatar: 'LFC' },
      { name: 'LFC Core', role: 'Лидер командной игры', avatar: 'LFC' },
    ],
    trophies: 0,
    roster: [],
    achievement: 'Элитный топ-клуб СНГ, один из сильнейших на текущий момент.',
    accent: 'from-rose-700 to-zinc-900',
    note: 'Элитный топ-клуб',
  },
  {
    id: 'shakhtar-academy',
    name: 'Академия Шахтера',
    tag: 'АКД',
    country: 'Украина',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/a/a1/FC_Shakhtar_Donetsk.svg',
    status: 'active',
    founded: 'Season 1',
    history: 'Молодёжная команда и кузница кадров для основного состава Шахтара. Академия развивает перспективных игроков и регулярно показывает зрелую игру в кубковых турнирах.',
    achievements: [
      { title: 'Призёр CIS League', season: 'Season 1', icon: 'medal' },
      { title: 'Участник кубкового плей-офф', season: 'Season 2', icon: 'cup' },
    ],
    keyPersons: [
      { name: 'Academy Coach', role: 'Главный тренер', avatar: 'АКД' },
      { name: 'Academy Captain', role: 'Капитан команды', avatar: 'АКД' },
      { name: 'Youth Core', role: 'Перспективные игроки', avatar: 'АКД' },
    ],
    trophies: 0,
    roster: [],
    achievement: 'Академия Шахтера, призёр турниров лиги.',
    accent: 'from-amber-700 to-zinc-900',
    note: 'Академия Шахтера',
  },
  {
    id: 'juventus',
    name: 'Ювентус',
    tag: 'JUV',
    country: 'СНГ',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/b/bc/Juventus_FC_2017_icon_%28black%29.svg',
    status: 'active',
    founded: 'Season 3',
    history: 'Клуб нового поколения, который быстро заявил о себе в третьем сезоне и дошёл до стадии полуфинала CIS Cup.',
    achievements: [{ title: 'Полуфиналист CIS Cup', season: 'Season 3', icon: 'cup' }],
    keyPersons: [{ name: 'JUV Captain', role: 'Капитан команды', avatar: 'JUV' }],
    trophies: 0,
    roster: [],
    achievement: 'Полуфиналист CIS Cup 3-го сезона.',
    accent: 'from-zinc-600 to-zinc-900',
    note: 'Полуфиналист CIS Cup',
  },
  {
    id: 'performance-fc',
    name: 'Performance FC',
    tag: 'PFC',
    country: 'СНГ',
    logo: '/image copy 3.png',
    status: 'inactive',
    founded: 'Season 2',
    history: 'Действующие чемпионы лиги, показавшие доминирующую игру. Клуб продолжил историю Кокомелона и оформил победы в CIS Cup S2 и S3.',
    achievements: [
      { title: 'Чемпион CIS League', season: 'Season 2', icon: 'trophy' },
      { title: 'Чемпион CIS Cup', season: 'Season 2', icon: 'cup' },
      { title: 'Чемпион CIS Cup', season: 'Season 3', icon: 'cup' },
    ],
    keyPersons: [
      { name: 'RiNO', role: 'Капитан и звёздный страйкер', avatar: 'RiNO' },
      { name: 'Dok', role: 'Ключевой плеймейкер', avatar: 'Dok' },
      { name: 'Trustme', role: 'Менеджер и тренер', avatar: 'TR' },
    ],
    trophies: 3,
    roster: ['RiNO', 'Dok', 'kakaska', 'Space7', 'r9zzon'],
    achievement: 'Легендарный чемпион 2-го и 3-го сезонов. Обладатель CIS Cup 2026.',
    accent: 'from-rose-600 to-rose-900',
    note: 'Действующий чемпион',
  },
  {
    id: 'pyatochek', name: 'Пяточек', tag: 'ПТЧ', country: 'СНГ', logo: '/image.png', status: 'inactive', founded: 'Season 1',
    history: 'Клуб с ярким выступлением во втором сезоне и сильной кубковой историей.',
    achievements: [{ title: 'Финалист гранд-финала', season: 'Season 2', icon: 'final' }],
    keyPersons: [{ name: 'Пяточек Captain', role: 'Капитан команды', avatar: 'ПТЧ' }], trophies: 0, roster: [], achievement: 'Финалист гранд-финала 2-го сезона.', accent: 'from-rose-700 to-zinc-900',
  },
  {
    id: 'ac-milan', name: 'AC Milan', tag: 'MIL', country: 'СНГ', logo: '/image.png', status: 'inactive', founded: 'Season 3',
    history: 'Амбициозный состав, который стал финалистом третьего сезона CIS Cup.',
    achievements: [{ title: 'Финалист CIS Cup', season: 'Season 3', icon: 'cup' }],
    keyPersons: [{ name: 'Milan Captain', role: 'Капитан команды', avatar: 'MIL' }], trophies: 0, roster: ['Ямал шалом', 'Cole palmer.', 'dream_vrfs_', 'timurdi.'], achievement: 'Финалист CIS Cup 3-го сезона.', accent: 'from-rose-700 to-zinc-900', note: 'Милан',
  },
  {
    id: 'wolverhampton', name: 'Wolverhampton Wanderers', tag: 'WLV', country: 'СНГ', logo: '/image.png', status: 'inactive', founded: 'Season 3',
    history: 'Клуб уверенно прошёл групповой этап и вошёл в число полуфиналистов CIS Cup.',
    achievements: [{ title: 'Полуфиналист CIS Cup', season: 'Season 3', icon: 'cup' }],
    keyPersons: [{ name: 'Mythic', role: 'Ключевой игрок', avatar: 'MY' }], trophies: 0, roster: ['Mythic', 'TMX', 'Vane4ka'], achievement: 'Полуфиналист CIS Cup 3-го сезона.', accent: 'from-amber-700 to-zinc-900', note: 'Вувлз',
  },
  {
    id: 'arsenal', name: 'Arsenal', tag: 'ARS', country: 'СНГ', logo: '/image.png', status: 'inactive', founded: 'Season 3',
    history: 'Участник третьего сезона, оставивший заметный след в кубковой сетке.', achievements: [{ title: 'Участник CIS Cup', season: 'Season 3', icon: 'medal' }], keyPersons: [{ name: 'xice', role: 'Представитель клуба', avatar: 'XI' }], trophies: 0, roster: ['xice'], achievement: 'Участник CIS Cup 3-го сезона.', accent: 'from-rose-700 to-zinc-900', note: 'Арсенал',
  },
  {
    id: 'newcastle', name: 'Newcastle United', tag: 'NEW', country: 'СНГ', logo: '/image.png', status: 'inactive', founded: 'Season 3',
    history: 'Клуб третьего сезона, зафиксированный в официальной сетке CIS Cup.', achievements: [{ title: 'Участник CIS Cup', season: 'Season 3', icon: 'medal' }], keyPersons: [{ name: 'Newcastle Captain', role: 'Капитан команды', avatar: 'NEW' }], trophies: 0, roster: [], achievement: 'Участник CIS Cup 3-го сезона (техническое поражение).', accent: 'from-zinc-600 to-zinc-900', note: 'Ньюкасл',
  },
  {
    id: 'aura-fc', name: 'Аура ФК', tag: 'АУР', country: 'СНГ', logo: '/image.png', status: 'inactive', founded: 'Season 1', history: 'Один из участников дебютного сезона CIS League.', achievements: [{ title: 'Участник лиги', season: 'Season 1', icon: 'medal' }], keyPersons: [{ name: 'Aura Captain', role: 'Капитан команды', avatar: 'АУР' }], trophies: 0, roster: [], achievement: 'Участник 1-го сезона лиги.', accent: 'from-emerald-700 to-zinc-900',
  },
  {
    id: 'barcha-fc', name: 'Барча ФК', tag: 'БРЧ', country: 'СНГ', logo: '/image.png', status: 'inactive', founded: 'Season 2', history: 'Участник второго сезона, вошедший в историю ранних турниров лиги.', achievements: [{ title: 'Участник лиги', season: 'Season 2', icon: 'medal' }], keyPersons: [{ name: 'Barcha Captain', role: 'Капитан команды', avatar: 'БРЧ' }], trophies: 0, roster: [], achievement: 'Участник 2-го сезона лиги.', accent: 'from-blue-700 to-zinc-900',
  },
];

export type RuleIconName =
  | 'shield'
  | 'footprints'
  | 'goal'
  | 'flag'
  | 'alert'
  | 'scale'
  | 'trophy'
  | 'users'
  | 'globe'
  | 'video'
  | 'activity'
  | 'file';

export interface RuleSection {
  title: string;
  icon: RuleIconName;
  points: string[];
}

export const aboutInfo = {
  whatIsVRFS:
    'VRFS (Virtual Reality Football Simulator) — киберспортивная футбольная дисциплина в виртуальной реальности. Игроки управляют футболистами от первого лица, используя VR-шлемы и контроллеры. Матчи проходят в реальном времени с полным физическим взаимодействием.',
  ruleSections: [
    {
      title: 'Глитчи ног и роста',
      icon: 'shield',
      points: [
        'Судья перед матчем и во время игры проверяет всех участников на наличие глитчей с ногами или нестандартным ростом.',
        'Если у игрока обнаружен глитч, судья выносит предупреждение и обязан отправить игрока на мгновенную перекалибровку.',
        'Если игрок отказывается перекалиброваться или игнорирует требование, он кикается с сервера или комнаты до полного исправления проблемы.',
      ],
    },
    {
      title: 'Удары от ворот',
      icon: 'footprints',
      points: [
        'Запрещено начинать движение с мячом, вести мяч или использовать глитч-дриблинг прямо с удара от ворот — разрешён только прямой пас или сильный удар вперёд.',
        'В случае нарушения в пользу соперника назначается пенальти.',
        'Исключение: если игрок совершил удар, но мяч вообще не сдвинулся с места из-за промаха или бага касания, разрешается повторный удар.',
      ],
    },
    {
      title: 'Угловые удары',
      icon: 'flag',
      points: [
        'При розыгрыше углового запрещено вести мяч — разрешается только прямой удар или пас партнёру.',
        'В штрафной площади мяч можно играть исключительно головой. Если мяч летит ниже пояса, на уровне земли, разрешается сыграть ногой.',
        'Нарушение карается ударом от ворот либо пенальти в пользу противоположной команды.',
        'Чтобы свободно играть ногами, игроки могут отдать пас за пределы штрафной площади.',
        'Вратарь обязан быть в перчатках, если планирует совершать прыжки за мячом.',
      ],
    },
    {
      title: 'Глитч-дриблинг',
      icon: 'alert',
      points: [
        'Использование любых багов, глитчей анимаций и нечестных механик для ведения мяча категорически запрещено.',
        'При фиксации нарушения сопернику назначается непрямой свободный удар или пенальти — в зависимости от зоны и позиции на поле.',
      ],
    },
    {
      title: 'Офсайд',
      icon: 'scale',
      points: [
        'При непосредственном исполнении удара от ворот правило офсайда не действует.',
        'Офсайд фиксируется, если атакующий игрок находится ближе к воротам соперника, чем предпоследний игрок обороняющейся команды, и касается мяча или участвует в эпизоде.',
        'Если игрок не касается мяча и не мешает эпизоду, не перекрывает обзор и не отвлекает соперника, офсайд не фиксируется.',
        'Игрок на одной линии с защитником считается находящимся в игре.',
        'После матча разрешена проверка взятия ворот по видео или реплею. Если в атаке был зафиксирован офсайд, гол отменяется.',
      ],
    },
    {
      title: 'Игровой мяч',
      icon: 'goal',
      points: [
        'Во всех официальных матчах разрешён только стандартный классический чёрно-белый мяч.',
        'Кастомные, пользовательские и модифицированные мячи строго запрещены.',
        'Использование стороннего мяча влечёт за собой полную переигровку матча.',
      ],
    },
    {
      title: 'Формат и продолжительность матча',
      icon: 'trophy',
      points: [
        'Основной формат — 6 на 6 или 7 на 7. При наличии достаточного количества игроков настоятельно рекомендуется формат 8 на 8 и больше.',
        'Матч длится 2 тайма по 10 минут. При ничьей в кубковых и плей-офф матчах назначается экстра-тайм длительностью 5 минут.',
        'В настройках комнаты обязательно должны быть включены Lights Rules.',
        'Разрешено не более 4 замен за весь матч.',
        'Если 3 человека одновременно идут в борьбу за мяч, это фиксируется как фол.',
      ],
    },
    {
      title: 'Сетевые и вратарские требования',
      icon: 'activity',
      points: [
        'Максимально допустимый пинг игрока на сервере — не более 160 мс.',
        'За использование запрещённого рывка вратаря (Goalie Dash) назначается пенальти.',
      ],
    },
    {
      title: 'Рефери и реплеи',
      icon: 'video',
      points: [
        'Игрокам запрещено вступать в споры с рефери. За споры и несогласие судья имеет право показать жёлтую карточку.',
        'Матчи можно играть без рефери, однако в таком случае обязателен Replay Code матча.',
        'Спорные эпизоды и нарушения отправляются администрации лиги исключительно в виде готовых видеозаписей.',
      ],
    },
    {
      title: 'Лимит легионеров',
      icon: 'users',
      points: [
        'В заявке команды может быть максимум 2 легионера — игрока, который не разговаривает и не понимает по-русски.',
        'На поле одновременно может находиться не более 1 легионера.',
      ],
    },
    {
      title: 'Состав и организация',
      icon: 'globe',
      points: [
        'Капитан команды отвечает за корректность заявки, связь с администрацией и соблюдение регламента всеми игроками.',
        'Участники обязаны соблюдать единые правила лиги и выполнять требования судьи во время матча.',
      ],
    },
    {
      title: 'Документы матча',
      icon: 'file',
      points: [
        'Результат матча, спорные моменты и подтверждающие материалы должны быть доступны администрации по запросу.',
        'Решения по спорным эпизодам принимаются на основании готовых видеозаписей и Replay Code.',
      ],
    },
  ] satisfies RuleSection[],
  howToJoin: [
    'Соберите состав команды и выберите капитана.',
    'Перейдите на официальный Discord-сервер лиги.',
    'Откройте соответствующий канал для заявок или тикетов и заполните анкету клуба.',
    'Пройдите верификацию состава у администрации и получите место в сетке турнира.',
  ],
};

export interface StandingRow {
  position: number;
  team: string;
  played: number;
  wins: number;
  draws: number;
  losses: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDiff: number;
  points: number;
  note?: string;
}

export interface GrandFinal {
  title: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  winner: string;
  description: string;
  scorers: { player: string; goals: number; label: string }[];
  note?: string;
}

export interface CupFinalPlayer {
  nickname: string;
  role: string;
  goals: number;
  assists: number;
  highlight: string;
}

export interface CupFinal {
  title: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  winner: string;
  summary: string;
  players: CupFinalPlayer[];
}

export interface MatchPlayerStat {
  nickname: string;
  goals: number;
  assists: number;
}

export interface PlayoffMatch {
  id: number;
  round: 'quarterfinal' | 'semifinal' | 'final';
  roundLabel: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  winner: string;
  note?: string;
  penaltyScore?: string;
  homePlayers?: MatchPlayerStat[];
  awayPlayers?: MatchPlayerStat[];
}

export interface PlayoffBracket {
  quarterfinals: PlayoffMatch[];
  semifinals: PlayoffMatch[];
  final: PlayoffMatch;
}

export interface Season {
  id: number;
  number: number;
  title: string;
  date: string;
  champion: string;
  championNote: string;
  standings: StandingRow[];
  grandFinal?: GrandFinal;
  cupFinal?: CupFinal;
  playoff?: PlayoffBracket;
  playoffNote?: string;
  format: string;
  status: 'completed' | 'special';
}

export const seasons: Season[] = [
  {
    id: 1,
    number: 1,
    title: 'CIS League · Season 1',
    date: '2025',
    champion: 'Шахтар Донецк',
    championNote: 'Чемпион Лиги и обладатель Кубка',
    format: 'Круговой турнир · 5 команд · 8 туров',
    status: 'completed',
    standings: [
      { position: 1, team: 'Шахтар', played: 8, wins: 8, draws: 0, losses: 0, goalsFor: 44, goalsAgainst: 3, goalDiff: 41, points: 24, note: 'Чемпион Лиги и обладатель Кубка' },
      { position: 2, team: 'Академия', played: 8, wins: 4, draws: 2, losses: 2, goalsFor: 28, goalsAgainst: 17, goalDiff: 11, points: 14 },
      { position: 3, team: 'Кокомелон', played: 8, wins: 2, draws: 2, losses: 4, goalsFor: 19, goalsAgainst: 21, goalDiff: -2, points: 8 },
      { position: 4, team: 'Пяточек', played: 8, wins: 1, draws: 3, losses: 4, goalsFor: 7, goalsAgainst: 30, goalDiff: -23, points: 6 },
      { position: 5, team: 'Аура ФК', played: 8, wins: 1, draws: 1, losses: 6, goalsFor: 7, goalsAgainst: 34, goalDiff: -27, points: 4 },
    ],
    cupFinal: {
      title: 'Финал Кубка · Season 1',
      homeTeam: 'Шахтар',
      awayTeam: 'Кокомелон',
      homeScore: 3,
      awayScore: 0,
      winner: 'Шахтар',
      summary:
        'Шахтар уверенно завоевал трофей Кубка первого сезона, всухую обыграв Кокомелон со счётом 3:0. Два гола были забиты в первой половине матча, третий закрепил итог в заключительной стадии. Защита во главе с вратарём Emik сохраняла «сухарь» на протяжении всей встречи.',
      players: [
        { nickname: 'florixxx', role: 'Нападающий', goals: 1, assists: 1, highlight: 'Гол + ассист — лидер атаки' },
        { nickname: 'Kairo', role: 'Нападающий', goals: 1, assists: 1, highlight: 'Гол + ассист' },
        { nickname: 'krupiv23', role: 'Полузащитник', goals: 1, assists: 0, highlight: 'Решающий гол' },
        { nickname: 'nkay_ / Yuto Kochegarov', role: 'Защитник', goals: 0, assists: 1, highlight: 'Активная игра в составе' },
        { nickname: 'Emik', role: 'Вратарь', goals: 0, assists: 0, highlight: 'Clean Sheet — сухой матч' },
        { nickname: 'Lioris', role: 'Защитник', goals: 0, assists: 0, highlight: 'Участие в матче' },
      ],
    },
    playoffNote: 'Сетка плей-офф Кубка 1-го сезона: Кокомелон vs Академия Шахтера, Шахтар vs Пяточек.',
    playoff: {
      quarterfinals: [
        {
          id: 101,
          round: 'quarterfinal',
          roundLabel: 'Полуфинал Кубка',
          homeTeam: 'Кокомелон',
          awayTeam: 'Академия Шахтера',
          homeScore: 0,
          awayScore: 0,
          winner: 'Кокомелон',
          note: 'Кокомелон прошёл в финал Кубка',
        },
        {
          id: 102,
          round: 'quarterfinal',
          roundLabel: 'Полуфинал Кубка',
          homeTeam: 'Шахтар',
          awayTeam: 'Пяточек',
          homeScore: 0,
          awayScore: 0,
          winner: 'Шахтар',
          note: 'Шахтар прошёл в финал Кубка',
        },
      ],
      semifinals: [],
      final: {
        id: 103,
        round: 'final',
        roundLabel: 'Финал Кубка · Season 1',
        homeTeam: 'Шахтар',
        awayTeam: 'Кокомелон',
        homeScore: 3,
        awayScore: 0,
        winner: 'Шахтар',
        note: 'См. протокол финала выше',
      },
    },
  },
  {
    id: 2,
    number: 2,
    title: 'CIS League · Season 2',
    date: '2025',
    champion: 'Performance FC',
    championNote: 'Чемпион Лиги и обладатель Кубка',
    format: 'Регулярный турнир + гранд-финал · 5 команд',
    status: 'completed',
    standings: [
      { position: 1, team: 'Performance FC', played: 3, wins: 2, draws: 1, losses: 0, goalsFor: 12, goalsAgainst: 3, goalDiff: 9, points: 7, note: 'бывш. Кокомелон' },
      { position: 2, team: 'Академия', played: 3, wins: 2, draws: 1, losses: 0, goalsFor: 11, goalsAgainst: 2, goalDiff: 9, points: 7 },
      { position: 3, team: 'Пяточек', played: 3, wins: 2, draws: 0, losses: 1, goalsFor: 6, goalsAgainst: 4, goalDiff: 2, points: 6 },
      { position: 4, team: 'Барча ФК', played: 4, wins: 1, draws: 0, losses: 3, goalsFor: 4, goalsAgainst: 15, goalDiff: -11, points: 3 },
      { position: 5, team: 'Арсенал БЛ', played: 3, wins: 0, draws: 0, losses: 3, goalsFor: 0, goalsAgainst: 9, goalDiff: -9, points: 0 },
    ],
    grandFinal: {
      title: 'Гранд-финал за трофей лиги',
      homeTeam: 'Performance FC',
      awayTeam: 'Пяточек',
      homeScore: 3,
      awayScore: 2,
      winner: 'Performance FC',
      description:
        'В решающем матче гранд-финала Performance FC одержали победу над Пяточком со счётом 3:2 благодаря невероятному перформансу лидеров. RiNO оформил хет-трик, Dok добавил дубль, а гениальный решающий ассист отдал правый защитник kakaska из глубины прямо в штрафную. Performance FC — чемпионы 2-го сезона.',
      scorers: [
        { player: 'RiNO', goals: 3, label: 'Хет-трик' },
        { player: 'Dok', goals: 2, label: 'Дубль' },
      ],
      note: 'Решающий ассист: kakaska (правый защитник) из глубины в штрафную',
    },
  },
  {
    id: 3,
    number: 3,
    title: 'CIS League · Season 3 — CIS Cup',
    date: '2026',
    champion: 'Performance FC',
    championNote: 'Обладатель CIS Cup 2026',
    format: 'Кубок СНГ (CIS Cup) · 8 команд · плей-офф',
    status: 'special',
    standings: [],
    playoffNote:
      'Чемпионат лиги в 3-м сезоне не проводился. Вместо полного сезона разыгрывался только Кубок СНГ (CIS Cup) с участием 8 команд и полной сеткой плей-офф.',
    playoff: {
      quarterfinals: [
        {
          id: 1,
          round: 'quarterfinal',
          roundLabel: 'Четвертьфинал',
          homeTeam: 'Wolverhampton',
          awayTeam: 'Arsenal',
          homeScore: 7,
          awayScore: 1,
          winner: 'Wolverhampton',
          homePlayers: [
            { nickname: 'Mythic', goals: 5, assists: 1 },
            { nickname: 'TMX⭐', goals: 1, assists: 3 },
            { nickname: 'Vane4ka✝️🍀', goals: 1, assists: 2 },
          ],
          awayPlayers: [
            { nickname: 'xice', goals: 1, assists: 0 },
          ],
        },
        {
          id: 2,
          round: 'quarterfinal',
          roundLabel: 'Четвертьфинал',
          homeTeam: 'AC Milan',
          awayTeam: 'Pyatochok',
          homeScore: 2,
          awayScore: 1,
          winner: 'AC Milan',
          homePlayers: [
            { nickname: 'timurdi.', goals: 1, assists: 0 },
            { nickname: 'Cole palmer.', goals: 1, assists: 0 },
          ],
          awayPlayers: [
            { nickname: 'qwentyq', goals: 1, assists: 0 },
          ],
        },
        {
          id: 3,
          round: 'quarterfinal',
          roundLabel: 'Четвертьфинал',
          homeTeam: 'Juventus',
          awayTeam: 'Newcastle United',
          homeScore: 3,
          awayScore: 0,
          winner: 'Juventus',
          note: 'Техническая победа (ff)',
        },
        {
          id: 4,
          round: 'quarterfinal',
          roundLabel: 'Четвертьфинал · Матч за звание топ-1 СНГ',
          homeTeam: 'Performance FC',
          awayTeam: 'Шахтар',
          homeScore: 4,
          awayScore: 1,
          winner: 'Performance FC',
          homePlayers: [
            { nickname: 'kakaska', goals: 2, assists: 1 },
            { nickname: 'Space7₊⋆⁺₊❅。', goals: 1, assists: 1 },
            { nickname: 'r9zzon', goals: 1, assists: 1 },
          ],
          awayPlayers: [
            { nickname: 'f/a', goals: 1, assists: 0 },
          ],
        },
      ],
      semifinals: [
        {
          id: 5,
          round: 'semifinal',
          roundLabel: 'Полуфинал',
          homeTeam: 'AC Milan',
          awayTeam: 'Juventus',
          homeScore: 2,
          awayScore: 2,
          winner: 'AC Milan',
          penaltyScore: '5:4',
          note: 'Победа по пенальти',
          homePlayers: [
            { nickname: 'Ямал шалом', goals: 2, assists: 0 },
            { nickname: 'Cole palmer.', goals: 0, assists: 1 },
            { nickname: 'dream_vrfs_', goals: 0, assists: 1 },
          ],
          awayPlayers: [
            { nickname: 'idk', goals: 0, assists: 0 },
          ],
        },
        {
          id: 6,
          round: 'semifinal',
          roundLabel: 'Полуфинал',
          homeTeam: 'Performance FC',
          awayTeam: 'Wolverhampton',
          homeScore: 6,
          awayScore: 0,
          winner: 'Performance FC',
          note: 'Mercy Rule',
          homePlayers: [
            { nickname: 'kakaska', goals: 2, assists: 0 },
            { nickname: 'Ƭʜᴇ𝕯𝖔k🔝', goals: 2, assists: 1 },
            { nickname: 'Space7₊⋆⁺₊❅。', goals: 2, assists: 1 },
            { nickname: 'RiNO✅', goals: 0, assists: 2 },
          ],
        },
      ],
      final: {
        id: 7,
        round: 'final',
        roundLabel: 'Финал · CIS Cup 2026',
        homeTeam: 'Performance FC',
        awayTeam: 'AC Milan',
        homeScore: 3,
        awayScore: 0,
        winner: 'Performance FC',
        homePlayers: [
          { nickname: 'Ƭʜᴇ𝕯𝖔k🔝', goals: 1, assists: 1 },
          { nickname: 'Space7₊⋆⁺₊❅。', goals: 1, assists: 1 },
          { nickname: 'RiNO✅', goals: 1, assists: 0 },
        ],
      },
    },
  },
];

export interface NewsArticle {
  id: number;
  tag: string;
  title: string;
  body: string;
  date: string;
}

export const news: NewsArticle[] = [
  {
    id: 1,
    tag: 'Аналитика',
    title: 'Итоги 1-го сезона: абсолютное доминирование Шахтара',
    body: 'Шахтар провёл образцовый сезон, не уступив ни одного матча и завершив турнир с 8 победами в 8 встречах. Разница мячей +41 (44:3) говорит сама за себя — конкурентов у чемпиона в этом сезоне попросту не было. Команда оформила двойной триумф: победитель Лиги и Кубка.',
    date: 'Season 1 · 2025',
  },
  {
    id: 2,
    tag: 'Аналитика',
    title: 'Академия: сильный сезон и уход лидеров',
    body: 'Академия стала единственной командой, способной хотя бы эпизодически тягаться с Шахтаром. 14 очков и второе место — достойный результат. Однако после сезона клуб покинули ключевые игроки, что поставило под угрозу дальнейшее развитие проекта.',
    date: 'Season 1 · 2025',
  },
  {
    id: 3,
    tag: 'Прогресс',
    title: 'Кокомелон → Performance FC: стремительный рост',
    body: 'Кокомелон, занявший лишь третье место в 1-м сезоне, кардинально перестроился и вернулся под новым именем Performance FC. Уже во 2-м сезоне команда стала триумфатором гранд-финала, а затем завоевала и CIS Cup в 3-м сезоне. Один из самых динамичных проектов лиги.',
    date: 'Season 1—3 · 2025—2026',
  },
  {
    id: 4,
    tag: 'Разочарование',
    title: 'Пяточек: слабое выступление',
    body: 'После 4-го места в 1-м сезоне (6 очков, разница −23) от Пяточка ждали большего. Во 2-м сезоне команда выступила лишь чуть лучше — 6 очков и 3-я строчка, но до борьбы за трофей было далеко. Клубу необходима перезагрузка состава.',
    date: 'Season 1—2 · 2025',
  },
  {
    id: 5,
    tag: 'Дебют',
    title: 'Аура ФК: первый сезон в лиге',
    body: 'Аура ФК дебютировала в 1-м сезоне и закономерно заняла последнее место — 4 очка, 1 победа, разница мячей −27. Тем не менее, опыт выступления на высоком уровне должен помочь команде в дальнейших сезонах.',
    date: 'Season 1 · 2025',
  },
  {
    id: 6,
    tag: 'Гранд-финал',
    title: 'Performance FC — чемпионы 2-го сезона!',
    body: 'В решающем матче гранд-финала Performance FC разгромили соперника благодаря невероятному перформансу: RiNO оформил хет-трик (3 гола), а Dok добавил дубль (2 гола). Итоговый счёт утвердил Performance FC в статусе триумфаторов 2-го сезона.',
    date: 'Season 2 · 2025',
  },
  {
    id: 7,
    tag: 'CIS Cup',
    title: 'Performance FC — обладатели Кубка 3-го сезона',
    body: 'Чемпионат лиги в 3-м сезоне был отменён. Вместо полного турнира разыграли только CIS Cup. Обладателем трофея вновь стала Performance FC, закрепив за собой статус доминирующей силы лиги.',
    date: 'Season 3 · 2026',
  },
];

export interface Legend {
  id: number;
  nickname: string;
  role: string;
  description: string;
  strengths: string[];
  achievements: string[];
  badge: string;
  draft?: boolean;
}

export const legends: Legend[] = [
  {
    id: 1,
    nickname: 'RiNO',
    role: 'Заполнить позже',
    description: 'Заполнить позже',
    strengths: ['Заполнить позже'],
    achievements: ['Заполнить позже'],
    badge: 'Шаблон игрока',
    draft: true,
  },
];
