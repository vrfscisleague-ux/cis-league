import { Crown, Star, Award, Zap, Target, Pencil } from 'lucide-react';
import { legends } from '@/data/mockData';

const PLACEHOLDER = 'Заполнить позже';

function isPlaceholder(value: string) {
  return value === PLACEHOLDER;
}

export default function Legends() {
  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-700 to-rose-950 ring-1 ring-rose-500/40">
          <Crown className="h-7 w-7 text-white" />
        </div>
        <h2 className="text-3xl font-extrabold text-white md:text-4xl">Почетные игроки СНГ</h2>
        <p className="mt-2 text-zinc-500">
          Легенды и ключевые игроки сообщества, чьи перформансы вошли в историю VRFS-лиги
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {legends.map((l) => {
          const draft = l.draft ?? false;
          return (
            <article
              key={l.id}
              className={`group relative flex flex-col overflow-hidden rounded-2xl border p-6 transition ${
                draft
                  ? 'border-dashed border-rose-700/50 bg-gradient-to-br from-rose-950/20 to-black hover:border-rose-600/80'
                  : 'border-zinc-800 bg-gradient-to-br from-zinc-950 to-black hover:border-rose-700/70'
              }`}
            >
              <div className="pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full bg-rose-800/10 blur-3xl transition group-hover:bg-rose-700/20" />

              {draft && (
                <span className="absolute right-4 top-4 inline-flex items-center gap-1 rounded-md border border-rose-700/40 bg-rose-950/60 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-rose-300">
                  <Pencil className="h-3 w-3" /> Шаблон
                </span>
              )}

              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-rose-700 to-rose-950 text-base font-extrabold text-white ring-1 ring-rose-500/40">
                    {l.nickname.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <h3 className="truncate text-lg font-extrabold text-white">{l.nickname}</h3>
                    <p className={`truncate text-xs ${isPlaceholder(l.role) ? 'italic text-zinc-600' : 'text-rose-400'}`}>
                      {l.role}
                    </p>
                  </div>
                </div>
              </div>

              <span className="mt-4 inline-flex w-fit items-center gap-1.5 rounded-md bg-rose-950/60 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider text-rose-300 ring-1 ring-rose-700/40">
                <Star className="h-3 w-3" /> {l.badge}
              </span>

              <p
                className={`mt-4 text-sm leading-relaxed ${
                  isPlaceholder(l.description) ? 'italic text-zinc-600' : 'text-zinc-400'
                }`}
              >
                {l.description}
              </p>

              {/* Strengths */}
              <div className="mt-5">
                <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-zinc-500">
                  <Zap className="h-3.5 w-3.5 text-rose-500" /> Лучшие качества
                </p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {l.strengths.map((s) => (
                    <span
                      key={s}
                      className={`rounded-md border px-2 py-1 text-xs font-semibold transition ${
                        isPlaceholder(s)
                          ? 'border-dashed border-zinc-700 bg-zinc-900/40 text-zinc-600'
                          : 'border-zinc-800 bg-zinc-900/60 text-zinc-300 hover:border-rose-700/50 hover:text-white'
                      }`}
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Achievements */}
              <div className="mt-5">
                <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-zinc-500">
                  <Award className="h-3.5 w-3.5 text-rose-500" /> Достижения в СНГ и вне
                </p>
                <ul className="mt-2 space-y-1.5">
                  {l.achievements.map((a, i) => (
                    <li
                      key={i}
                      className={`flex gap-2 text-xs ${
                        isPlaceholder(a) ? 'italic text-zinc-600' : 'text-zinc-400'
                      }`}
                    >
                      <Target className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-500" />
                      <span className="leading-relaxed">{a}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
