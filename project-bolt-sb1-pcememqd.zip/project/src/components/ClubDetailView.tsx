import { ArrowLeft, Calendar, Crown, MapPin, Shield, Star, Trophy, Users } from 'lucide-react';
import { type Club } from '@/data/mockData';

interface ClubDetailViewProps {
  club: Club;
  onBack: () => void;
}

export default function ClubDetailView({ club, onBack }: ClubDetailViewProps) {
  const isChampion = club.note === 'Действующий чемпион';

  return (
    <div className="space-y-6">
      <button type="button" onClick={onBack} className="inline-flex items-center gap-2 rounded-lg border border-red-900/50 bg-neutral-900/80 px-4 py-2.5 text-sm font-bold text-neutral-200 transition-all hover:border-red-500/80 hover:text-white">
        <ArrowLeft className="h-4 w-4" /> Назад к списку клубов
      </button>

      <section className="relative overflow-hidden rounded-2xl border border-red-900/50 bg-gradient-to-br from-neutral-900 to-black p-6 md:p-10">
        <div className={`pointer-events-none absolute -right-20 -top-24 h-72 w-72 rounded-full bg-gradient-to-br ${club.accent} opacity-20 blur-3xl`} />
        <div className="relative flex flex-col gap-6 sm:flex-row sm:items-center">
          <div className="flex h-28 w-28 shrink-0 items-center justify-center rounded-2xl border border-neutral-800 bg-black/60 p-3 shadow-2xl shadow-red-950/30">
            <img src={club.logo} alt={`${club.name} — логотип`} className="h-full w-full object-contain" />
          </div>
          <div>
            <div className="mb-3 flex flex-wrap gap-2">
              <span className={`rounded-md px-3 py-1 text-xs font-bold uppercase tracking-wider ${isChampion ? 'bg-red-600 text-white shadow-lg shadow-red-950/50' : club.status === 'active' ? 'bg-emerald-950/70 text-emerald-300 ring-1 ring-emerald-600/50' : 'bg-zinc-800 text-zinc-300 ring-1 ring-zinc-700'}`}>
                {isChampion ? 'Действующий чемпион' : club.status === 'active' ? 'Действующий клуб' : 'Архивный клуб'}
              </span>
              <span className="rounded-md bg-black/50 px-3 py-1 text-xs font-bold uppercase tracking-wider text-zinc-400 ring-1 ring-zinc-800">{club.founded}</span>
            </div>
            <h1 className="text-3xl font-black text-white md:text-5xl">{club.name}</h1>
            <p className="mt-2 flex items-center gap-2 text-sm text-zinc-500"><MapPin className="h-4 w-4 text-red-500" /> {club.country}</p>
          </div>
        </div>
      </section>

      <section className="rounded-2xl border border-red-900/50 bg-neutral-900/80 p-6 md:p-8">
        <div className="flex items-center gap-3"><Shield className="h-6 w-6 text-red-500" /><h2 className="text-xl font-bold text-white md:text-2xl">История клуба</h2></div>
        <p className="mt-4 max-w-4xl leading-relaxed text-neutral-300">{club.history}</p>
        <div className="mt-6 flex items-center gap-2 text-sm text-zinc-500"><Calendar className="h-4 w-4 text-red-500" /> Основан в {club.founded}</div>
      </section>

      <section className="rounded-2xl border border-red-900/50 bg-black/60 p-6 md:p-8">
        <div className="flex items-center gap-3"><Trophy className="h-6 w-6 text-red-500" /><h2 className="text-xl font-bold text-white md:text-2xl">Достижения и трофеи</h2></div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {club.achievements.map((achievement) => (
            <article key={`${achievement.title}-${achievement.season}`} className="rounded-xl border border-red-900/40 bg-neutral-900/80 p-5 transition-all hover:border-red-600/60">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-950/70 text-red-400 ring-1 ring-red-800/50"><Crown className="h-5 w-5" /></div>
              <h3 className="mt-4 font-bold text-white">{achievement.title}</h3>
              <p className="mt-1 text-sm text-red-400">{achievement.season}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="rounded-2xl border border-red-900/50 bg-neutral-900/80 p-6 md:p-8">
        <div className="flex items-center gap-3"><Star className="h-6 w-6 text-red-500" /><h2 className="text-xl font-bold text-white md:text-2xl">Значимые персоны</h2></div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {club.keyPersons.map((person) => (
            <article key={`${person.name}-${person.role}`} className="flex items-center gap-4 rounded-xl border border-red-900/40 bg-black/60 p-4 transition-all hover:border-red-600/60">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-red-600 to-red-950 text-xs font-black text-white ring-1 ring-red-500/40">{person.avatar ?? person.name.slice(0, 2).toUpperCase()}</div>
              <div><h3 className="font-bold text-white">{person.name}</h3><p className="mt-1 text-sm text-zinc-400">{person.role}</p></div>
            </article>
          ))}
        </div>
        <p className="mt-6 flex items-center gap-2 text-sm text-zinc-500"><Users className="h-4 w-4 text-red-500" /> Основной состав: {club.roster.length ? club.roster.join(', ') : 'данные уточняются'}</p>
      </section>
    </div>
  );
}
