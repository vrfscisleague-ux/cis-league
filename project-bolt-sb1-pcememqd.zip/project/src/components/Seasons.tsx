import { useState } from 'react';
import { Calendar, Trophy, Crown, Target, Star, Newspaper, ChevronRight, Shield, Goal, Hand, GitBranch } from 'lucide-react';
import { seasons, news, type StandingRow, type CupFinal, type PlayoffBracket, type PlayoffMatch } from '@/data/mockData';

function CupFinalCard({ cup }: { cup: CupFinal }) {
  return (
    <div className="mt-6 overflow-hidden rounded-xl border border-rose-700/50 bg-gradient-to-br from-rose-950/50 via-black to-black">
      <div className="border-b border-rose-900/50 px-6 py-4">
        <div className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-rose-400" />
          <h4 className="text-lg font-bold text-white">{cup.title}</h4>
        </div>
      </div>

      {/* Scoreline */}
      <div className="flex items-center justify-center gap-6 px-6 py-8">
        <div className="flex flex-1 flex-col items-end">
          <span className={`text-lg font-extrabold md:text-2xl ${cup.winner === cup.homeTeam ? 'text-white' : 'text-zinc-400'}`}>
            {cup.homeTeam}
          </span>
        </div>
        <div className="flex items-center gap-3 rounded-xl border border-rose-700/40 bg-black/60 px-5 py-3">
          <span className={`text-3xl font-black md:text-4xl ${cup.winner === cup.homeTeam ? 'text-rose-400' : 'text-zinc-300'}`}>{cup.homeScore}</span>
          <span className="text-xl font-bold text-zinc-600">:</span>
          <span className={`text-3xl font-black md:text-4xl ${cup.winner === cup.awayTeam ? 'text-rose-400' : 'text-zinc-300'}`}>{cup.awayScore}</span>
        </div>
        <div className="flex flex-1 flex-col items-start">
          <span className={`text-lg font-extrabold md:text-2xl ${cup.winner === cup.awayTeam ? 'text-white' : 'text-zinc-400'}`}>
            {cup.awayTeam}
          </span>
        </div>
      </div>

      <div className="flex items-center justify-center gap-2 pb-5">
        <Crown className="h-4 w-4 text-rose-400" />
        <span className="text-sm font-bold text-rose-300">Обладатель Кубка: {cup.winner}</span>
      </div>

      <p className="px-6 pb-5 text-sm leading-relaxed text-zinc-400">{cup.summary}</p>

      {/* Match protocol */}
      <div className="border-t border-rose-900/40 px-6 py-5">
        <h5 className="mb-4 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-zinc-500">
          <Goal className="h-3.5 w-3.5 text-rose-500" /> Протокол матча · отличившиеся игроки
        </h5>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {cup.players.map((p) => (
            <div
              key={p.nickname}
              className="flex items-start gap-3 rounded-lg border border-zinc-800 bg-zinc-950/60 p-4 transition hover:border-rose-700/60 hover:bg-rose-950/20"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-rose-700 to-rose-950 text-xs font-extrabold text-white ring-1 ring-rose-500/40">
                {p.nickname.slice(0, 2).toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-bold text-white">{p.nickname}</p>
                <p className="text-[11px] uppercase tracking-wider text-zinc-500">{p.role}</p>
                <p className="mt-1 text-xs text-rose-300">{p.highlight}</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {p.goals > 0 && (
                    <span className="inline-flex items-center gap-1 rounded bg-rose-950/60 px-1.5 py-0.5 text-[11px] font-bold text-rose-300 ring-1 ring-rose-700/40">
                      <Target className="h-3 w-3" /> {p.goals} {p.goals === 1 ? 'гол' : 'гола'}
                    </span>
                  )}
                  {p.assists > 0 && (
                    <span className="inline-flex items-center gap-1 rounded bg-zinc-900 px-1.5 py-0.5 text-[11px] font-bold text-zinc-300 ring-1 ring-zinc-700">
                      <Shield className="h-3 w-3" /> {p.assists} {p.assists === 1 ? 'ассист' : 'ассиста'}
                    </span>
                  )}
                  {p.goals === 0 && p.assists === 0 && (
                    <span className="inline-flex items-center gap-1 rounded bg-zinc-900 px-1.5 py-0.5 text-[11px] font-bold text-zinc-400 ring-1 ring-zinc-700">
                      <Hand className="h-3 w-3" /> в игре
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function PlayerStatChips({ players, side }: { players: { nickname: string; goals: number; assists: number }[]; side: 'home' | 'away' }) {
  if (!players || players.length === 0) return null;
  const accent = side === 'home' ? 'text-rose-300' : 'text-zinc-300';
  return (
    <div className="mt-3 flex flex-wrap gap-1.5">
      {players.map((p) => (
        <span
          key={p.nickname}
          className={`inline-flex items-center gap-1.5 rounded-md border border-zinc-800 bg-black/50 px-2 py-1 text-[11px] font-semibold ${accent}`}
        >
          {p.nickname}
          {p.goals > 0 && <span className="inline-flex items-center gap-0.5 text-rose-400"><Target className="h-3 w-3" />{p.goals}</span>}
          {p.assists > 0 && <span className="inline-flex items-center gap-0.5 text-zinc-400"><Shield className="h-3 w-3" />{p.assists}</span>}
        </span>
      ))}
    </div>
  );
}

function MatchCard({ match }: { match: PlayoffMatch }) {
  const homeWon = match.winner === match.homeTeam;
  const awayWon = match.winner === match.awayTeam;
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-950/60 p-4 transition hover:border-rose-700/50">
      <div className="mb-2 flex items-center justify-between">
        <span className="rounded bg-rose-950/60 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-rose-300 ring-1 ring-rose-700/40">
          {match.roundLabel}
        </span>
        {match.note && <span className="text-[10px] font-semibold text-zinc-500">{match.note}</span>}
      </div>
      <div className="flex items-center gap-3">
        <div className="flex-1 text-right">
          <span className={`text-sm font-bold ${homeWon ? 'text-white' : 'text-zinc-500'}`}>{match.homeTeam}</span>
        </div>
        <div className="flex items-center gap-2 rounded-lg border border-rose-700/30 bg-black/60 px-3 py-1.5">
          <span className={`text-lg font-black ${homeWon ? 'text-rose-400' : 'text-zinc-400'}`}>{match.homeScore}</span>
          <span className="text-xs font-bold text-zinc-600">:</span>
          <span className={`text-lg font-black ${awayWon ? 'text-rose-400' : 'text-zinc-400'}`}>{match.awayScore}</span>
        </div>
        <div className="flex-1">
          <span className={`text-sm font-bold ${awayWon ? 'text-white' : 'text-zinc-500'}`}>{match.awayTeam}</span>
        </div>
      </div>
      {match.penaltyScore && (
        <p className="mt-2 text-center text-[11px] font-semibold text-rose-400">Пенальти: {match.penaltyScore}</p>
      )}
      <PlayerStatChips players={match.homePlayers ?? []} side="home" />
      <PlayerStatChips players={match.awayPlayers ?? []} side="away" />
    </div>
  );
}

function PlayoffBracketCard({ bracket, note }: { bracket: PlayoffBracket; note?: string }) {
  return (
    <div className="mt-6 rounded-xl border border-rose-700/40 bg-gradient-to-br from-rose-950/30 to-black p-6">
      <div className="flex items-center gap-2">
        <GitBranch className="h-5 w-5 text-rose-400" />
        <h4 className="text-lg font-bold text-white">Сетка плей-офф</h4>
      </div>
      {note && <p className="mt-2 text-sm text-zinc-400">{note}</p>}

      {bracket.quarterfinals.length > 0 && (
        <div className="mt-5">
          <p className="mb-2 text-xs font-bold uppercase tracking-widest text-zinc-500">Четвертьфиналы · 1/4</p>
          <div className="grid gap-3 sm:grid-cols-2">
            {bracket.quarterfinals.map((m) => <MatchCard key={m.id} match={m} />)}
          </div>
        </div>
      )}

      {bracket.semifinals.length > 0 && (
        <div className="mt-5">
          <p className="mb-2 text-xs font-bold uppercase tracking-widest text-zinc-500">Полуфиналы · 1/2</p>
          <div className="grid gap-3 sm:grid-cols-2">
            {bracket.semifinals.map((m) => <MatchCard key={m.id} match={m} />)}
          </div>
        </div>
      )}

      <div className="mt-5">
        <p className="mb-2 text-xs font-bold uppercase tracking-widest text-rose-400">Финал</p>
        <div className="mx-auto max-w-md">
          <div className="rounded-xl border border-rose-600/50 bg-gradient-to-br from-rose-950/60 to-black p-5">
            <div className="mb-3 flex items-center justify-center gap-2 text-rose-300">
              <Crown className="h-4 w-4" />
              <span className="text-[11px] font-bold uppercase tracking-wider">{bracket.final.roundLabel}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-1 text-right">
                <span className={`text-base font-extrabold ${bracket.final.winner === bracket.final.homeTeam ? 'text-white' : 'text-zinc-500'}`}>{bracket.final.homeTeam}</span>
              </div>
              <div className="flex items-center gap-2 rounded-lg border border-rose-600/50 bg-black/70 px-4 py-2">
                <span className={`text-2xl font-black ${bracket.final.winner === bracket.final.homeTeam ? 'text-rose-400' : 'text-zinc-400'}`}>{bracket.final.homeScore}</span>
                <span className="text-sm font-bold text-zinc-600">:</span>
                <span className={`text-2xl font-black ${bracket.final.winner === bracket.final.awayTeam ? 'text-rose-400' : 'text-zinc-400'}`}>{bracket.final.awayScore}</span>
              </div>
              <div className="flex-1">
                <span className={`text-base font-extrabold ${bracket.final.winner === bracket.final.awayTeam ? 'text-white' : 'text-zinc-500'}`}>{bracket.final.awayTeam}</span>
              </div>
            </div>
            {bracket.final.note && <p className="mt-2 text-center text-[11px] text-zinc-500">{bracket.final.note}</p>}
            <PlayerStatChips players={bracket.final.homePlayers ?? []} side="home" />
            <PlayerStatChips players={bracket.final.awayPlayers ?? []} side="away" />
            <div className="mt-3 flex items-center justify-center gap-2">
              <Trophy className="h-4 w-4 text-rose-400" />
              <span className="text-sm font-bold text-rose-300">Победитель: {bracket.final.winner}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StandingsTable({ rows }: { rows: StandingRow[] }) {
  if (rows.length === 0) {
    return (
      <p className="rounded-lg border border-zinc-800 bg-zinc-950/60 p-6 text-center text-sm text-zinc-500">
        Турнирная таблица не проводилась в этом сезоне.
      </p>
    );
  }
  return (
    <div className="overflow-x-auto rounded-xl border border-zinc-800">
      <table className="w-full text-sm">
        <thead className="bg-zinc-950 text-left text-[11px] uppercase tracking-wider text-zinc-500">
          <tr>
            <th className="px-3 py-3 font-semibold">#</th>
            <th className="px-3 py-3 font-semibold">Команда</th>
            <th className="px-2 py-3 text-center font-semibold">И</th>
            <th className="px-2 py-3 text-center font-semibold">В</th>
            <th className="px-2 py-3 text-center font-semibold">Н</th>
            <th className="px-2 py-3 text-center font-semibold">П</th>
            <th className="px-2 py-3 text-center font-semibold">Мячи</th>
            <th className="px-2 py-3 text-center font-semibold">+/-</th>
            <th className="px-3 py-3 text-center font-semibold">О</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-zinc-900">
          {rows.map((r) => (
            <tr
              key={`${r.position}-${r.team}`}
              className={`transition hover:bg-rose-950/20 ${
                r.position === 1 ? 'bg-rose-950/25' : 'bg-black/40'
              }`}
            >
              <td className="px-3 py-3">
                <span
                  className={`flex h-6 w-6 items-center justify-center rounded-md text-xs font-extrabold ${
                    r.position === 1
                      ? 'bg-gradient-to-br from-rose-600 to-rose-900 text-white ring-1 ring-rose-500/50'
                      : 'bg-zinc-900 text-zinc-400'
                  }`}
                >
                  {r.position}
                </span>
              </td>
              <td className="px-3 py-3">
                <div className="font-bold text-white">{r.team}</div>
                {r.note && <div className="text-[11px] text-rose-400/80">{r.note}</div>}
              </td>
              <td className="px-2 py-3 text-center text-zinc-300">{r.played}</td>
              <td className="px-2 py-3 text-center font-semibold text-white">{r.wins}</td>
              <td className="px-2 py-3 text-center text-zinc-400">{r.draws}</td>
              <td className="px-2 py-3 text-center text-zinc-400">{r.losses}</td>
              <td className="px-2 py-3 text-center text-zinc-300">
                {r.goalsFor}:{r.goalsAgainst}
              </td>
              <td className={`px-2 py-3 text-center font-semibold ${r.goalDiff > 0 ? 'text-emerald-400' : r.goalDiff < 0 ? 'text-rose-400' : 'text-zinc-400'}`}>
                {r.goalDiff > 0 ? '+' : ''}{r.goalDiff}
              </td>
              <td className="px-3 py-3 text-center">
                <span className="font-extrabold text-white">{r.points}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function Seasons() {
  const [active, setActive] = useState(seasons[0].id);
  const season = seasons.find((s) => s.id === active) ?? seasons[0];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-extrabold text-white md:text-4xl">История сезонов</h2>
        <p className="mt-2 text-zinc-500">Турнирные таблицы, гранд-финалы и итоги всех сезонов CIS League</p>
      </div>

      {/* Season tabs */}
      <div className="flex flex-wrap gap-2">
        {seasons.map((s) => (
          <button
            key={s.id}
            onClick={() => setActive(s.id)}
            className={`group flex items-center gap-3 rounded-lg border px-4 py-3 text-left transition ${
              active === s.id
                ? 'border-rose-600/70 bg-gradient-to-br from-rose-950/60 to-black'
                : 'border-zinc-800 bg-zinc-950/40 hover:border-rose-700/40'
            }`}
          >
            <div
              className={`flex h-10 w-10 items-center justify-center rounded-lg text-sm font-extrabold ${
                active === s.id
                  ? 'bg-gradient-to-br from-rose-600 to-rose-900 text-white'
                  : 'bg-zinc-900 text-zinc-400'
              }`}
            >
              S{s.number}
            </div>
            <div>
              <p className={`text-sm font-bold ${active === s.id ? 'text-white' : 'text-zinc-300'}`}>
                Season {s.number}
              </p>
              <p className="text-[11px] text-zinc-500">{s.date}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Active season block */}
      <section className="rounded-2xl border border-rose-950/60 bg-gradient-to-br from-zinc-950 to-black p-6 md:p-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-rose-400">
              <Calendar className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase tracking-widest">{season.format}</span>
            </div>
            <h3 className="mt-2 text-2xl font-extrabold text-white">{season.title}</h3>
          </div>
          <div className="flex items-center gap-3 rounded-xl border border-rose-700/40 bg-rose-950/40 px-4 py-3">
            <Crown className="h-7 w-7 text-rose-400" />
            <div>
              <p className="text-[11px] uppercase tracking-wider text-zinc-500">Чемпион</p>
              <p className="text-lg font-extrabold text-white">{season.champion}</p>
              <p className="text-xs text-rose-400">{season.championNote}</p>
            </div>
          </div>
        </div>

        {/* Standings */}
        <div className="mt-6">
          <h4 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-zinc-400">
            <Trophy className="h-4 w-4 text-rose-500" /> Турнирная таблица
          </h4>
          <StandingsTable rows={season.standings} />
        </div>

        {/* Cup final */}
        {season.cupFinal && <CupFinalCard cup={season.cupFinal} />}

        {/* Grand final */}
        {season.grandFinal && (
          <div className="mt-6 rounded-xl border border-rose-700/40 bg-gradient-to-br from-rose-950/50 to-black p-6">
            <div className="flex items-center gap-2">
              <Star className="h-5 w-5 text-rose-400" />
              <h4 className="text-lg font-bold text-white">{season.grandFinal.title}</h4>
            </div>
            <div className="mt-4 flex items-center justify-center gap-4">
              <span className={`text-lg font-extrabold ${season.grandFinal.winner === season.grandFinal.homeTeam ? 'text-white' : 'text-zinc-500'}`}>{season.grandFinal.homeTeam}</span>
              <div className="flex items-center gap-2 rounded-lg border border-rose-700/40 bg-black/60 px-4 py-2">
                <span className={`text-3xl font-black ${season.grandFinal.winner === season.grandFinal.homeTeam ? 'text-rose-400' : 'text-zinc-300'}`}>{season.grandFinal.homeScore}</span>
                <span className="text-base font-bold text-zinc-600">:</span>
                <span className={`text-3xl font-black ${season.grandFinal.winner === season.grandFinal.awayTeam ? 'text-rose-400' : 'text-zinc-300'}`}>{season.grandFinal.awayScore}</span>
              </div>
              <span className={`text-lg font-extrabold ${season.grandFinal.winner === season.grandFinal.awayTeam ? 'text-white' : 'text-zinc-500'}`}>{season.grandFinal.awayTeam}</span>
            </div>
            <p className="mt-4 leading-relaxed text-zinc-300">{season.grandFinal.description}</p>
            {season.grandFinal.note && (
              <p className="mt-2 text-sm font-semibold text-rose-400">{season.grandFinal.note}</p>
            )}
            {season.grandFinal.scorers.length > 0 && (
              <div className="mt-5 flex flex-wrap gap-3">
                {season.grandFinal.scorers.map((sc) => (
                  <div
                    key={sc.player}
                    className="flex items-center gap-3 rounded-lg border border-rose-700/40 bg-black/40 px-4 py-3"
                  >
                    <Target className="h-5 w-5 text-rose-400" />
                    <div>
                      <p className="font-extrabold text-white">{sc.player}</p>
                      <p className="text-xs text-rose-400">
                        {sc.goals} {sc.goals === 1 ? 'гол' : sc.goals < 5 ? 'гола' : 'голов'} · {sc.label}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Playoff bracket */}
        {season.playoff && <PlayoffBracketCard bracket={season.playoff} note={season.playoffNote} />}
      </section>

      {/* News */}
      <section>
        <h3 className="mb-5 flex items-center gap-2 text-xl font-bold text-white">
          <Newspaper className="h-5 w-5 text-rose-500" /> Новости и пресс-служба лиги
        </h3>
        <div className="grid gap-4 md:grid-cols-2">
          {news.map((n) => (
            <article
              key={n.id}
              className="group flex flex-col rounded-xl border border-zinc-800 bg-zinc-950/60 p-5 transition hover:border-rose-700/60 hover:bg-rose-950/20"
            >
              <div className="flex items-center justify-between">
                <span className="rounded-md bg-rose-950/60 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider text-rose-300 ring-1 ring-rose-700/40">
                  {n.tag}
                </span>
                <span className="text-[11px] text-zinc-600">{n.date}</span>
              </div>
              <h4 className="mt-3 text-base font-bold text-white">{n.title}</h4>
              <p className="mt-2 text-sm leading-relaxed text-zinc-400">{n.body}</p>
              <span className="mt-3 flex items-center gap-1 text-xs font-semibold text-rose-400 opacity-0 transition group-hover:opacity-100">
                Подробнее <ChevronRight className="h-3 w-3" />
              </span>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
