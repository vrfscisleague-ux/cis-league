import { Users, Shield, Trophy, Coins, ArrowRight, Calendar, Radio } from 'lucide-react';
import type { TabKey } from './Header';
import { stats, currentSeason, hallOfFame } from '@/data/mockData';

interface HomeProps {
  onTab: (tab: TabKey) => void;
}

const statCards = [
  { icon: Users, label: 'Участников', value: stats.totalPlayers, suffix: '+' },
  { icon: Shield, label: 'Активных клубов', value: stats.activeClubs, suffix: '' },
  { icon: Trophy, label: 'Сезонов сыграно', value: stats.seasonsPlayed, suffix: '' },
  { icon: Coins, label: 'Призовой фонд', value: stats.prizePool, suffix: '' },
];

export default function Home({ onTab }: HomeProps) {
  const lastChampion = hallOfFame[hallOfFame.length - 1];
  const firstLegend = 'RiNO';

  return (
    <div className="space-y-10">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-2xl border border-rose-950/60 bg-gradient-to-br from-zinc-950 via-black to-rose-950/40 p-8 md:p-14">
        <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-rose-700/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -left-10 h-72 w-72 rounded-full bg-rose-900/30 blur-3xl" />
        <div className="relative max-w-2xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-rose-500/40 bg-rose-950/50 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-rose-300">
            <Radio className="h-3 w-3" /> {currentSeason.status}
          </span>
          <h2 className="mt-5 text-4xl font-extrabold leading-tight text-white md:text-6xl">
            Главная VRFS-лига <span className="bg-gradient-to-r from-rose-400 to-rose-700 bg-clip-text text-transparent">СНГ</span>
          </h2>
          <p className="mt-4 text-lg text-zinc-400">
            Премиальный киберспортивный чемпионат по виртуальному футболу. Лучшие клубы, элитные игроки и настоящий накал страстей на поле.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <button
              onClick={() => onTab('legends')}
              className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-br from-rose-600 to-rose-900 px-5 py-3 font-bold text-white ring-1 ring-rose-500/50 transition hover:from-rose-500 hover:to-rose-800"
            >
              Почетные игроки СНГ <ArrowRight className="h-4 w-4" />
            </button>
            <button
              onClick={() => onTab('about')}
              className="inline-flex items-center gap-2 rounded-lg border border-zinc-700 px-5 py-3 font-bold text-white transition hover:border-rose-500/60 hover:bg-rose-950/30"
            >
              Как принять участие
            </button>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {statCards.map((s) => (
          <div
            key={s.label}
            className="group rounded-xl border border-zinc-800 bg-zinc-950/60 p-5 transition hover:border-rose-700/60 hover:bg-rose-950/20"
          >
            <s.icon className="h-7 w-7 text-rose-500 transition group-hover:scale-110" />
            <p className="mt-3 text-2xl font-extrabold text-white md:text-3xl">{s.value}{s.suffix}</p>
            <p className="mt-1 text-sm text-zinc-500">{s.label}</p>
          </div>
        ))}
      </section>

      {/* Current season + quick links */}
      <section className="grid gap-4 lg:grid-cols-3">
        <div className="rounded-xl border border-rose-900/60 bg-gradient-to-br from-rose-950/40 to-black p-6 lg:col-span-2">
          <div className="flex items-center gap-2 text-rose-400">
            <Calendar className="h-5 w-5" />
            <h3 className="text-lg font-bold text-white">Текущий сезон</h3>
          </div>
          <p className="mt-1 text-sm text-zinc-500">{currentSeason.name}</p>
          <p className="mt-4 text-zinc-300">{currentSeason.description}</p>
          <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
            <div>
              <p className="text-xs uppercase tracking-wider text-zinc-500">Старт</p>
              <p className="mt-1 font-bold text-white">{currentSeason.startDate}</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wider text-zinc-500">Финал</p>
              <p className="mt-1 font-bold text-white">{currentSeason.endDate}</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wider text-zinc-500">Команд</p>
              <p className="mt-1 font-bold text-white">{currentSeason.teams}</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wider text-zinc-500">Призы</p>
              <p className="mt-1 font-bold text-rose-400">{currentSeason.prizePool}</p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <button
            onClick={() => onTab('hall')}
            className="flex w-full items-center justify-between rounded-xl border border-zinc-800 bg-zinc-950/60 p-5 text-left transition hover:border-rose-700/60 hover:bg-rose-950/20"
          >
            <div>
              <p className="text-xs uppercase tracking-wider text-zinc-500">Действующий чемпион</p>
              <p className="mt-1 text-lg font-bold text-white">{lastChampion.champion}</p>
              <p className="text-xs text-rose-400">{lastChampion.season} · {lastChampion.date} · Season 2</p>
            </div>
            <Trophy className="h-8 w-8 text-rose-500" />
          </button>
          <button
            onClick={() => onTab('legends')}
            className="flex w-full items-center justify-between rounded-xl border border-zinc-800 bg-zinc-950/60 p-5 text-left transition hover:border-rose-700/60 hover:bg-rose-950/20"
          >
            <div>
              <p className="text-xs uppercase tracking-wider text-zinc-500">Легенда лиги</p>
              <p className="mt-1 text-lg font-bold text-white">{firstLegend}</p>
              <p className="text-xs text-rose-400">Performance FC · Снайпер</p>
            </div>
            <ArrowRight className="h-6 w-6 text-zinc-500" />
          </button>
        </div>
      </section>
    </div>
  );
}
