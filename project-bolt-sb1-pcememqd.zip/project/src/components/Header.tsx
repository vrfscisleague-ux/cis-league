
export type TabKey = 'home' | 'hall' | 'legends' | 'clubs' | 'about';

interface HeaderProps {
  active: TabKey;
  onTab: (tab: TabKey) => void;
}

const tabs: { key: TabKey; label: string }[] = [
  { key: 'home', label: 'Главная' },
  { key: 'hall', label: 'Зал Славы & Сезоны' },
  { key: 'legends', label: 'Почетные игроки СНГ' },
  { key: 'clubs', label: 'Клубы СНГ' },
  { key: 'about', label: 'О лиге' },
];

export default function Header({ active, onTab }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 border-b border-rose-950/60 bg-black/90 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-4 md:flex-row md:items-center md:justify-between md:px-6">
        <a href="#home" className="flex items-center gap-3" aria-label="CIS League — на главную">
          <img
            src="/image%20copy.png"
            alt="CIS League VRFS Esports"
            className="h-12 w-auto object-contain"
          />
        </a>

        <nav className="flex flex-wrap items-center gap-1 md:gap-2">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => onTab(t.key)}
              className={`relative rounded-md px-3 py-2 text-sm font-semibold transition-colors md:px-4 ${
                active === t.key
                  ? 'text-white'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              {t.label}
              {active === t.key && (
                <span className="absolute inset-x-2 -bottom-[1px] h-0.5 rounded-full bg-gradient-to-r from-rose-500 to-rose-700" />
              )}
            </button>
          ))}
          <a
            href="https://discord.gg/7jqPHqnMCJ"
            target="_blank"
            rel="noopener noreferrer"
            className="ml-2 hidden items-center gap-2 rounded-md bg-gradient-to-br from-rose-700 to-rose-950 px-4 py-2 text-sm font-bold text-white ring-1 ring-rose-500/40 transition-all hover:from-rose-600 hover:to-rose-900 hover:ring-rose-400/60 md:flex"
          >
            Discord (180+)
          </a>
        </nav>
      </div>
    </header>
  );
}
