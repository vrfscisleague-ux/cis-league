import { useState } from 'react';
import Header, { type TabKey } from '@/components/Header';
import ClubDetailView from '@/components/ClubDetailView';
import { clubs } from '@/data/mockData';
import Home from '@/components/Home';
import HallOfFame from '@/components/HallOfFame';
import Legends from '@/components/Legends';
import Seasons from '@/components/Seasons';
import Clubs from '@/components/Clubs';
import About from '@/components/About';

function App() {
  const [tab, setTab] = useState<TabKey>('home');
  const [selectedClubId, setSelectedClubId] = useState<string | null>(null);
  const selectedClub = clubs.find((club) => club.id === selectedClubId);

  const handleTabChange = (nextTab: TabKey) => {
    setTab(nextTab);
    setSelectedClubId(null);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Header active={tab} onTab={handleTabChange} />
      <main className="mx-auto max-w-7xl px-4 py-8 md:px-6 md:py-12">
        {tab === 'home' && <Home onTab={setTab} />}
        {tab === 'hall' && (
          <>
            <Seasons />
            <div className="mt-12">
              <HallOfFame />
            </div>
          </>
        )}
        {tab === 'legends' && <Legends />}
        {tab === 'clubs' && (selectedClub ? <ClubDetailView club={selectedClub} onBack={() => setSelectedClubId(null)} /> : <Clubs onSelectClub={setSelectedClubId} />)}
        {tab === 'about' && <About />}
      </main>
      <footer className="border-t border-rose-950/40 py-8 text-center text-xs text-zinc-600">
        <p>CIS LEAGUE · VRFS Esports · 2023—2026</p>
        <p className="mt-1 text-zinc-700">Премиальный киберспортивный чемпионат СНГ</p>
      </footer>
    </div>
  );
}

export default App;
